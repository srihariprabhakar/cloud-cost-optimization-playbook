## Reserved Instances vs Spot Instances

**Reserved Instances:** Best for predictable workloads

**Spot Instances:** Best for batch jobs, stateless services