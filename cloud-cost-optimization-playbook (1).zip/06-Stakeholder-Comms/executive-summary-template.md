# Monthly Cost Optimization Summary

**Client:** [Name]  
**Month:** [Date Range]  
**Summary:**  
- Total savings this month: $X,XXX  
- Top 3 initiatives:  
  1. Rightsizing VMs  
  2. Implementing schedules  
  3. Moving to Reserved Instances

**Next Steps:**  
- Present QBR  
- Plan next savings sprint
