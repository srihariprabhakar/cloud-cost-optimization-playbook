Use cloud-native tools (e.g., Azure Automation, AWS Lambda) to:
- Start/stop non-critical VMs
- Clean up temp storage