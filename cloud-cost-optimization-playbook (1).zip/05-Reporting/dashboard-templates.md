Use PowerBI or Cost Explorer to track:
- Spend by department
- RI coverage/utilization
- Top unused resources