## Quick Wins: Resource Cleanup

1. Delete unattached disks
2. Clean up old snapshots
3. Stop dev/test VMs after hours